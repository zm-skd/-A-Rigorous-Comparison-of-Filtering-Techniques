
% 只做海岸线前2000

clc
clear all
close all

%%%%%%% 读取遥感图像%%%%%%%
[data,lat,lon,latjiange,lonjiange]=read_ENVIimagefile_img('1.img');
load 去海岸图.mat
folderName = 'G:\切割数据-文章8\25'; 
mkdir(folderName);

%%%%%%% 参数初始化 %%%%%%%
lat= rot90(lat); % 旋转90度
[Mm,Nn]=size(data);
numMm=Mm;  % 减1为了防止出问题
% numNn=Nn;

%%%%%%% 寻找图像中的第一个0元素（海岸）%%%%%%%
first_nonzero_indices = zeros(size(data, 1), 1);
for row = 1:size(data, 1)
    nonzero_indices = find(data(row, :) ~= 0); % 找到非零元素的索引
    if ~isempty(nonzero_indices)
        first_nonzero_indices(row) = nonzero_indices(1); % 获取第一个非零元素的索引
    else
        first_nonzero_indices(row) = 0; % 如果整行都是零，则索引为0
    end
end

%%%%%%% 图像分割 %%%%%%%
inum=0;
for iim=500:25:numMm-500 %防止边界溢出，根据元的尺寸修改
    iim
    
    numNn=first_nonzero_indices(iim);
    for iin=numNn:25:numNn+5000
        if data(iim,iin)==0
            continue
        end

%%%%%%% 判断单元大小 %%%%%%%
% sizeele=400;
% sizeele=round((0.117*(iin-numNn))+50);  %第一种

sizeele=round(133.33*atanh((iin-numNn)/5050)+50);%第二种
% 
% sizeele=round(359.712*atanh((iin-numNn)/4000)+50);
% A = 0.117;  
% B = 50; 
% x0=iin-numNn;
% y0=sizeele;
% x_symm =((2.*y0)+(x0./A)-(A.*x0)-(2*B))/((A)+(1/A));
% x1=x_symm;
% y_symm = (-x1/A)+(y0)+(x0/A);
% sizeele=round(y_symm);%第三种

%%%%%%% 判断切割方法 %%%%%%%

              if  all(first_nonzero_indices(iim:iim+sizeele)<=iin) % 判断海岸线是否侵入了图像
              OutImg = data(iim:iim+sizeele,iin:iin+sizeele);    
              latmiddle=round((sizeele/2)+iim);
              lonmiddle=round((sizeele/2)+iin);
              latmn=lat(latmiddle,1);
              lonmn=lon(1,lonmiddle);
              inum=inum+1;
              Data(inum,1)=latmn;
              Data(inum,2)=lonmn;
              filenamePrefix='Fenge';
              filename = strcat(filenamePrefix, num2str(inum), '.mat');
              save([folderName, '\', filename], 'OutImg'); 
              end

              if  all(first_nonzero_indices(iim-sizeele:iim)<=iin) % 判断海岸线是否侵入了图像
              OutImg = data(iim-sizeele:iim,iin:iin+sizeele); 
              latmiddle=round(iim-(sizeele/2));
              lonmiddle=round((sizeele/2)+iin);
              latmn=lat(latmiddle,1);
              lonmn=lon(1,lonmiddle);
              inum=inum+1;
              Data(inum,1)=latmn;
              Data(inum,2)=lonmn;
              filenamePrefix='Fenge';
              filename = strcat(filenamePrefix, num2str(inum), '.mat');
              save([folderName, '\', filename], 'OutImg'); 
              end          
%%%%%%% 保存每个矩阵为mat文件 %%%%%%%
          
    end
end

%%%%%%% 保存经纬度文件 %%%%%%%
save([folderName, '\', 'LatLon.mat'], 'Data');
