
clc;
clear all
%%%%%%%%%%% 读取图像%%%%%%%%%%%

for II=23:23
filename = strcat('G:\切割数据-文章8\25\Fenge', num2str(II), '.mat');    
load (filename)

OutImg = Normalize(OutImg);
OutImg = uint8(OutImg);
% OutImg = replaceZerosWithAverage(OutImg);
[M,N]=size(OutImg);
%  figure;
%  subplot(1,2,1);imagesc(OutImg);title('原图');
II
try
%%%%%%%%%%% 快速傅里叶%%%%%%%%%%%
Y1 = fft2(OutImg);

Y1=abs(fftshift(Y1));
[rows0,cols0]=find(Y1 == max(max(Y1)));  % 去中心
Y1(rows0,cols0)=0;

subplot(1,2,2);
imagesc(Y1);

%%%%%%%% 波长求解%%%%%%%%%%
Lenths=5;
    %分量1波长求解
Lmadanew1=0;
[row1,col1]=extrmax(Y1,3);
[mm1,nn1]=size(row1);
for i=1:mm1
   Lmada1=Lenths/(sqrt((abs(row1(i,1)-rows0)/(2*M))^2+((abs(col1(i,1)-cols0)/(2*N))^2))); 
   Lmadaev1(i,1)= Lmada1;
   Lmadanew1=Lmadanew1+Lmada1; 
end
   Lmadam1=Lmadanew1/mm1;
   Data(II,1)=Lmadam1;
end
end
%  save('lamada3.mat', 'Data');