
clear all
close all
%%%%%%%%%%%%% 定义经度和纬度的范围 %%%%%%%%%%%% 
load wave-4.mat
max_value1 = max(unnamed(:, 1)); % 第n列的最大值
min_value1 = min(unnamed(:, 1)); % 第n列的最小值
max_value2 = max(unnamed(:, 2)); % 第n列的最大值
min_value2 = min(unnamed(:, 2)); % 第n列的最小值
lon_min = min_value2; % 经度最小值  
lon_max = max_value2;  % 经度最大值  
lat_min = min_value1;  % 纬度最小值  
lat_max = max_value1;   % 纬度最大值  

%%%%%%%%%%%%% 定义经度和纬度的分辨率（即网格的大小）  %%%%%%%%%%%%
lon_res = 0.001;  % 经度分辨率  降低了分辨率 
lat_res = 0.001;  % 纬度分辨率 

%%%%%%%%%%%% 使用meshgrid创建网格点  %%%%%%%%%%%%
[lon_grid, lat_grid] = meshgrid(lon_min:lon_res:lon_max, lat_max:-lat_res:lat_min);  
data_matrix = zeros(size(lat_grid)); % 所有值初始化为0  
[M,N]=size(unnamed);
for i=1:M
    Lat1=unnamed(i,1);
    Lon1=unnamed(i,2);
[~,I1]=min(abs(lat_grid(:,1)-Lat1));
[~,I2]=min(abs(lon_grid(1,:)-Lon1));
data_matrix(I1,I2)=unnamed(i,3);
% figure;
% imshow(data_matrix,[]);
end

%%%%%%%%%%%% 填充%%%%%%%%%%%%
data_matrix_non0=find(data_matrix==0); 
data_matrix(data_matrix_non0)=NaN;
OutImg=fillNaN(data_matrix); %填充研究区域内的NaN值
OutImgdex=OutImg;
figure
surf(lon_grid(1,:),lat_grid(:,1),OutImg);

Aout = OutImg; %原始矩阵   
B1 = nan(size(Aout));  
[m, n] = size(Aout);  % 获取矩阵的行数和列数 
for i = 9:452 
    % 查找当前行第一个非NaN值的索引  
    firstNonNaN = find(~isnan(Aout(i, :)), 1, 'first');  
    % 如果没有找到非NaN值，则跳过该行  
    if isempty(firstNonNaN)  
        continue;  
    end  

    startIndex = firstNonNaN + 1;  % 计算起始列索引  
    % 确保起始索引不超过矩阵的列数  
    if startIndex > n  
        continue; % 如果起始索引超出列数，则跳过该行  
    end  

    endIndex1 = 285;% 保证不超出矩阵列数
    B1(i, startIndex:endIndex1-1) = Aout(i, startIndex:endIndex1-1);  
 Nan_indices = isnan(B1(i, 1:75-1));  %视情况而定，担心海岸线以内存在NAN值 
 B1(i,Nan_indices) = 0;   %使用逻辑索引将NaN替换为0     
  
% 找到第一个非 NaN 元素的索引
%     firstNonNanIdx = find(~isnan(B1(i,:)), 1, 'first');    
%     % 如果找到了非 NaN 元素
%     if ~isempty(firstNonNanIdx)
%         % 将该元素前面的所有元素都设置为 0
%         B1(i, 1:firstNonNanIdx-1) = 0;
%     end
end  

figure
surf(lon_grid(1,:),lat_grid(:,1),B1);
OutImg=B1; 
img1 = OutImg; 
sheet = 'Sheet9';
%%%%%%%%%%%% 高斯滤波器%%%%%%%%%%%%    
% h = fspecial('gaussian', [40 40],15); % 创建一个5x5大小的高斯滤波器，标准差为5  
% filtered_img1 = imfilter(double(img1), h,'replicate');  % 应用滤波器
% figure
% surf(lon_grid(1,:),lat_grid(:,1),filtered_img1);

%%%%%%%%%%%% 双边滤波器%%%%%%%%%%%
% degreeOfSmoothing = 50000;
% spatialSigma = 5;
% filtered_img1 = imbilatfilt(img1, degreeOfSmoothing, spatialSigma);
% figure
% surf(lon_grid(1,:),lat_grid(:,1),filtered_img1);

%%%%%%%%%%%%Savitzky-Golay 滤波器%%%%%%%%%%%
% windowSize = 1001; % 窗口大小1
% polynomialOrder = 20; % 多项式阶数
% filtered_img1 = sgolayfilt(img1, polynomialOrder, windowSize);
% surf(lon_grid(1,:),lat_grid(:,1),filtered_img1);

%%%%%%%%%%%% 移动平均滤波器 %%%%%%%%%%%%
% windowSize = [40 40];
% filtered_img1 = movmean(img1, windowSize);
% figure
% surf(lon_grid(1,:),lat_grid(:,1),filtered_img1);

%%%%%%%%%%%% 中值滤波器%%%%%%%%%%%
windowSize =[40 40];
filtered_img1= medfilt2(img1, windowSize);
figure
surf(lon_grid(1,:),lat_grid(:,1),filtered_img1);

%%%%%%%%%%%%求水深%%%%%%%%%%%%
filtered_img=filtered_img1;
maxValue = max(filtered_img(:))+10; % 使用(:)将矩阵A转换为一个列向量，然后找出最大值  
% maxValue = 500; % 使用(:)将矩阵A转换为一个列向量，然后找出最大值   
% 初始化一个新的矩阵B，用于存储与最大值运算后的结果  
Bfiltered_img = zeros(size(filtered_img)); % 创建一个与A大小相同的零矩阵  
for i = 1:size(filtered_img, 1)  
    for j = 1:size(filtered_img, 2)         
          Bfiltered_img(i, j) =-1.5*(filtered_img(i, j)/(2*pi))*atanh(filtered_img(i, j)/maxValue); % 将A中的每个元素与最大值相减，结果存储在B中  
         % Bfiltered_img(i, j) =-(2*filtered_img(i, j)/(2*pi))*atanh(filtered_img(i, j)/maxValue); % 将A中的每个元素与最大值相减，结果存储在B中  
    end  
end  
figure
surf(lon_grid(1,:),lat_grid(:,1),Bfiltered_img);

%%%%%%%%%%%% 去后列的NaN%%%%%%%%%%%%
Bfiltered_img1=Bfiltered_img(:,1:324);%127取决于Bfiltered_img最后的NaN值的列数
Bfiltered_img2=Bfiltered_img(:,325:end);%128取决于Bfiltered_img最后的NaN值的列数
OutImg=Bfiltered_img1; 
img1 = OutImg; 
%%%%%%%%%%%% 高斯滤波器%%%%%%%%%%%%

% h = fspecial('gaussian', [20 20],10); % 创建一个5x5大小的高斯滤波器，标准差为5  
% filtered_img1 = imfilter(double(img1), h,'replicate');  % 应用滤波器
filtered_img1=img1;
filtered_img1=[filtered_img1,Bfiltered_img2];
figure
surf(lon_grid(1,:),lat_grid(:,1),filtered_img1);

%%%%%%%%%%%%切割原有范围%%%%%%%%%%%%
load 海岸线.mat
for i=1:459
   for ii=1:363
Lat1=lat_grid(i,1);
[~,I]=min(abs(data2(:,1)-Lat1));
    if lon_grid(1,ii)>data2(I,2)
    depthfinal(i,ii)=filtered_img1(i,ii);
    wavefinal(i,ii)=filtered_img(i,ii);
    else
    depthfinal(i,ii)=NaN;
    wavefinal(i,ii)=NaN;
    end
   end
end
figure('Position', [100 100 1000 600]);
h=surf(lon_grid(1,:),lat_grid(:,1),depthfinal);
colormap(slanCM('viridis'));
colorbar;
view(60, 30);
cb=colorbar;
title(cb, 'Depth(m)'); % 水深添加标题
clim([-120 -5]);  %水深范围限制
h.EdgeAlpha = 0.5; % 线的透明度，范围0到1
% 去掉坐标轴
axis off;
% 去掉网格线
grid off;
% 如果需要去掉背景网格（即网格线和坐标轴之间的背景颜色），可以使用：
set(gca, 'Color', 'none');
print(gcf, '-dtiff', sheet, '-r300');

figure
surf(lon_grid(1,:),lat_grid(:,1),wavefinal);
% save('depth-2.mat', 'depthfinal');
% save('lat1.mat', 'lat_grid');
% save('lon1.mat', 'lon_grid');

%%%%%%%%%%%%导出二维数据%%%%%%%%%%%%
 numbera=1;
for i=1:459
   for ii=1:363
    depthma(numbera,1)=lat_grid(i,1);
    depthma(numbera,2)=lon_grid(1,ii);
    depthma(numbera,3)=depthfinal(i,ii);
    depthma(numbera,4)=wavefinal(i,ii);
    numbera=numbera+1;
   end
end
% 找到每行是否包含 NaN
rowsWithNaN = any(isnan(depthma), 2);
% 删除包含 NaN 的行
depthma(rowsWithNaN, :) = [];
% save('depthma-2.mat', 'depthma');

% 定义文件名和工作表名    
filename = 'D:\中值滤波器.xlsx';

% 将矩阵写入 Excel 文件
writematrix(depthma, filename, 'Sheet', sheet, 'Range', 'A2');
% 提示操作完成
disp('数据已写入 Excel 文件的 Sheet1 中');
  